class DecompileError(Exception):
    pass
